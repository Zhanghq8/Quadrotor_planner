/* 
 * lpastar.hpp
 * 
 * Created on: Nov 30, 2017 14:21
 * Description: Lifelong Planning A* algorithm
 * 
 * Copyright (c) 2017 Ruixiang Du (rdu)
 */ 

#ifndef LPASTAR_HPP
#define LPASTAR_HPP

namespace librav {

class LPAStar
{

};

}

#endif /* LPASTAR_HPP */
